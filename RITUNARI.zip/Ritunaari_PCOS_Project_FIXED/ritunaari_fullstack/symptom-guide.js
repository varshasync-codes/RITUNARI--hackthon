const symptomForm = document.getElementById('symptomForm');
const descriptionInput = document.getElementById('symptomDescription');
const charCount = document.getElementById('charCount');
const statusBox = document.getElementById('formStatus');
const resultBox = document.getElementById('symptomResult');
let latestSummary = '';

if (descriptionInput) descriptionInput.addEventListener('input', () => { charCount.textContent = descriptionInput.value.length; });

function readForm() {
  const data = new FormData(symptomForm);
  return {
    description: String(data.get('description') || '').trim(),
    duration: data.get('duration') || 'unsure',
    no_period_90_days: data.get('noPeriod') === 'yes',
    rapid_change: data.get('rapidChange') === 'yes',
    severe_warning_signs: data.getAll('warning'),
    age_group: data.get('age_group') || 'prefer-not-to-say'
  };
}

// Local fallback keeps the demonstration usable if the API has not been started.
function localGuidance(data) {
  const text = data.description.toLowerCase();
  const patterns = [];
  const rules = [
    [['irregular period','irregular periods','missed period','missed periods','late period','no period'], 'Menstrual-cycle changes', 'Cycle changes can be associated with PCOS, but other causes such as stress, pregnancy, thyroid conditions and medicines may also affect periods.'],
    [['facial hair','chin hair','upper lip hair','body hair','hair growth'], 'Increased facial or body hair', 'This can be associated with higher androgen levels, including in PCOS, but is not specific to PCOS.'],
    [['acne','pimples','breakouts'], 'Acne', 'Acne has many causes and can sometimes occur with hormonal changes.'],
    [['hair thinning','hair loss','thinning hair'], 'Scalp hair thinning', 'Hair thinning can have several causes that a clinician can assess.'],
    [['tired','fatigue','low energy'], 'Tiredness or low energy', 'Tiredness is nonspecific; sleep, iron levels, thyroid conditions and stress can be relevant.']
  ];
  rules.forEach(([words,label,explanation]) => { if (words.some(w => text.includes(w))) patterns.push({label, explanation}); });
  const warningText = {
    'severe-pain':'Severe or sudden pelvic/abdominal pain needs urgent medical assessment.',
    'fainting':'Fainting or feeling close to fainting with symptoms needs urgent assessment.',
    'heavy-bleeding':'Very heavy bleeding, especially with weakness or dizziness, needs urgent medical care.',
    'pregnancy-pain-bleeding':'If pregnancy is possible and you have pain or bleeding, seek prompt urgent assessment.',
    'fever':'Fever with pelvic pain or unusual discharge should be assessed promptly.'
  };
  let urgency='routine', title='Consider a routine health assessment';
  let next_steps=['Book a routine appointment if symptoms persist, recur, or worry you.','Bring a record of period dates, symptom changes, medicines, and questions for the clinician.','A clinician can consider other causes and decide whether tests are appropriate.'];
  const warnings = data.severe_warning_signs.map(x => warningText[x]).filter(Boolean);
  if (warnings.length) { urgency='urgent'; title='Please prioritise medical care'; next_steps=[...warnings,'Do not rely on this tool to assess an urgent symptom. Contact local emergency services if symptoms are severe or you feel unsafe.']; }
  else if (data.rapid_change) { urgency='prompt'; title='Arrange a prompt medical assessment'; next_steps=['Rapid changes in facial/body hair or other hormone-related features deserve timely assessment.','Tell the clinician when the change started and how quickly it progressed.']; }
  else if (data.no_period_90_days) { urgency='appointment'; title='Book a healthcare appointment'; next_steps=['Going about 90 days without a period merits assessment, particularly if periods were previously established.','If pregnancy is possible, consider a pregnancy test and discuss the result with a healthcare professional.']; }
  else if (!patterns.length && data.duration === 'unsure') { urgency='information'; title='Gather a little more context'; next_steps=['Track when symptoms occur, how often, and whether they are changing.','If symptoms persist, recur, or concern you, arrange a healthcare appointment.']; }
  if (data.age_group==='under-18') next_steps.push('For teenagers, PCOS assessment needs particular care because normal puberty changes can overlap with symptoms. A qualified clinician can interpret symptoms in context.');
  if (!patterns.length) patterns.push({label:'No clear symptom keywords identified', explanation:'This prototype may not recognise the words you used. It cannot rule a condition in or out.'});
  return {title, urgency, patterns, next_steps, pcos_note:'These symptoms may overlap with PCOS but do not diagnose it. Assessment depends on age and clinical context, and other causes may need to be considered.', privacy:'This prototype does not save your symptom description.', disclaimer:'Educational care navigation only; not a diagnosis or substitute for a qualified healthcare professional.'};
}

function renderGuidance(data, result) {
  document.getElementById('resultTitle').textContent = result.title;
  const badge = document.getElementById('urgencyBadge');
  badge.textContent = ({urgent:'Urgent care',prompt:'Prompt assessment',appointment:'Appointment recommended',routine:'Routine guidance',information:'More context needed'})[result.urgency] || 'Guidance';
  badge.className = 'urgency-badge urgency-' + result.urgency;
  const patterns = document.getElementById('resultPatterns'); patterns.replaceChildren();
  result.patterns.forEach(item => { const article=document.createElement('article'); article.className='pattern-card'; const h=document.createElement('h3'); h.textContent=item.label; const p=document.createElement('p'); p.textContent=item.explanation; article.append(h,p); patterns.append(article); });
  const steps=document.getElementById('nextSteps'); steps.replaceChildren();
  result.next_steps.forEach(item => { const li=document.createElement('li'); li.textContent=item; steps.append(li); });
  document.getElementById('pcosNote').textContent=result.pcos_note;
  document.getElementById('privacyNote').textContent=result.privacy;
  document.getElementById('disclaimerText').textContent=result.disclaimer;
  latestSummary = `RITUNAARI — APPOINTMENT PREPARATION\nDescription: ${data.description}\nDuration: ${data.duration}\nNo period for 90 days: ${data.no_period_90_days?'Yes':'No / unsure'}\nRapid symptom change: ${data.rapid_change?'Yes':'No / unsure'}\nPossible patterns: ${result.patterns.map(p=>p.label).join(', ')}\nSuggested questions: What could explain these symptoms? Is PCOS assessment appropriate? Are any tests needed?\n\nThis is a user-entered summary, not a diagnosis.`;
  resultBox.hidden=false; resultBox.scrollIntoView({behavior:'smooth',block:'start'});
}

symptomForm?.addEventListener('submit', async event => {
  event.preventDefault();
  const data=readForm();
  if (data.description.length<3) { statusBox.textContent='Please add a little more detail so the tool can respond.'; return; }
  const button=document.getElementById('submitSymptoms'); button.disabled=true; button.textContent='Preparing your guidance…'; statusBox.textContent='Reviewing your description. Your symptoms are not saved by this feature.';
  try {
    const response=await fetch('http://127.0.0.1:8000/api/symptom-guide',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    if (!response.ok) throw new Error('API unavailable');
    renderGuidance(data, await response.json()); statusBox.textContent='Guidance ready.';
  } catch (error) {
    renderGuidance(data, localGuidance(data)); statusBox.textContent='Demo mode: the API was not reachable, so local prototype rules were used. Start the backend for the API version.';
  } finally { button.disabled=false; button.textContent='Help me understand next steps ↗'; }
});

document.getElementById('copySummary')?.addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(latestSummary); statusBox.textContent='Appointment summary copied.'; }
  catch { const area=document.createElement('textarea'); area.value=latestSummary; document.body.append(area); area.select(); document.execCommand('copy'); area.remove(); statusBox.textContent='Appointment summary copied.'; }
});
document.getElementById('startOver')?.addEventListener('click', () => { symptomForm.reset(); charCount.textContent='0'; resultBox.hidden=true; statusBox.textContent=''; window.scrollTo({top:0,behavior:'smooth'}); });
